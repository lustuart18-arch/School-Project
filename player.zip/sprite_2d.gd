extends Sprite2D

var is_grabbed : bool = false
var is_hovering : bool = false

func _process(_delta):
	
	if is_grabbed:
		var mouse_pos = get_global_mouse_position()
		global_position = lerp(global_position, mouse_pos, 0.2)
		return
		
func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			is_grabbed = true
		else:
			is_grabbed = false
